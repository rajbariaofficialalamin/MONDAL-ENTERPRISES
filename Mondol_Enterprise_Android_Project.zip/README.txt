MONDOL ENTERPRISE Android WebView app project

App label: মন্ডল এন্টারপ্রাইজ
Launcher icon: cropped portrait from the photo supplied in this conversation.
Startup URL: https://zippy-zabaione-b5222d.netlify.app

This ZIP is an Android Studio source project, NOT a compiled APK.
To build an installable APK:
1. Open this folder in Android Studio.
2. Let Gradle sync finish.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will show the APK output location.

The app displays the current live website inside the app. Website content and language
will reflect whatever is currently deployed on Netlify. Any website changes must be
deployed to Netlify separately.
